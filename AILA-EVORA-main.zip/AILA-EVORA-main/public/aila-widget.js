/**
 * AILA Chat Widget - Embeddable Script
 * Add this to any website: <script src="https://aila-speak-feel.lovable.app/aila-widget.js"></script>
 * 
 * This script creates an iframe that loads the full React widget with all features:
 * - Floating chat button in lower right corner
 * - Welcome bubble
 * - Close button
 * - Voice conversation mode
 * - Responsive design
 */

(function() {
  'use strict';

  // Prevent multiple instances
  if (window.ailaWidgetLoaded) {
    return;
  }
  window.ailaWidgetLoaded = true;

  // Create iframe container
  iframe.src = 'https://aila-speak-feel.lovable.app/?embed=1';
  iframe.style.cssText = `
    position: fixed !important;
    bottom: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    border: none !important;
    z-index: 2147483647 !important;
  `;
  iframe.allow = 'microphone';
  iframe.title = 'Aila Chat Assistant';
  iframe.setAttribute('aria-label', 'Aila Chat Assistant Widget');

  // Add to page when DOM is ready
  function init() {
    document.body.appendChild(iframe);

    // Listen for messages from iframe (e.g., close button clicked)
    window.addEventListener('message', (event) => {
      if (event.data === 'aila-close-chat') {
        // Optionally handle close event from inside widget
        // For now we keep the iframe visible so user can reopen via the button
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Public API for conversion tracking
  window.ailaTrackConversion = function() {
    iframe.contentWindow?.postMessage('aila-track-conversion', '*');
  };
})();
