-- Drop the overly permissive update policy
DROP POLICY IF EXISTS "Anyone can update sessions" ON public.analytics_sessions;

-- Create a more restrictive policy that only allows updating recent sessions
CREATE POLICY "Can only update recent sessions" 
ON public.analytics_sessions 
FOR UPDATE 
USING (created_at > (now() - interval '24 hours'));