-- Add RLS policies to prevent unauthorized modifications to analytics_sessions
CREATE POLICY "Only admins can update sessions" 
ON public.analytics_sessions 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can delete sessions" 
ON public.analytics_sessions 
FOR DELETE 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add RLS policies to prevent unauthorized modifications to analytics_events
CREATE POLICY "Only admins can update events" 
ON public.analytics_events 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can delete events" 
ON public.analytics_events 
FOR DELETE 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add RLS policies to prevent unauthorized modifications to page_visits
CREATE POLICY "Only admins can update page visits" 
ON public.page_visits 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can delete page visits" 
ON public.page_visits 
FOR DELETE 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add RLS policies to protect user_roles table from privilege escalation
CREATE POLICY "Only admins can insert user roles" 
ON public.user_roles 
FOR INSERT 
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can update user roles" 
ON public.user_roles 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can delete user roles" 
ON public.user_roles 
FOR DELETE 
USING (has_role(auth.uid(), 'admin'::app_role));