-- Fix analytics_sessions security: Only admins should update sessions
-- Anonymous users can only INSERT new sessions, not modify existing ones

DROP POLICY IF EXISTS "Allow session updates by session_id" ON public.analytics_sessions;

-- Admin-only update policy (for analytics dashboard)
CREATE POLICY "Only admins can update analytics sessions"
ON public.analytics_sessions
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (
  -- Keep validation checks
  COALESCE(total_messages, 0) >= 0
  AND COALESCE(total_messages, 0) <= 1000
  AND COALESCE(user_messages, 0) >= 0
  AND COALESCE(bot_messages, 0) >= 0
  AND COALESCE(duration_seconds, 0) >= 0
  AND COALESCE(duration_seconds, 0) <= 86400
  AND (ended_at IS NULL OR ended_at >= started_at)
);