-- Fix analytics_sessions RLS policy to allow initial inserts with minimal data
DROP POLICY IF EXISTS "Allow validated session inserts" ON public.analytics_sessions;

CREATE POLICY "Allow validated session inserts"
ON public.analytics_sessions
FOR INSERT
WITH CHECK (
  -- Ensure session_id is provided
  session_id IS NOT NULL
  -- Ensure started_at is reasonable (not in future, not too old)
  AND (started_at IS NULL OR (started_at <= now() AND started_at >= now() - interval '24 hours'))
  -- Allow NULL for optional numeric fields on initial insert
  AND (total_messages IS NULL OR (total_messages >= 0 AND total_messages <= 1000))
  AND (user_messages IS NULL OR user_messages >= 0)
  AND (bot_messages IS NULL OR bot_messages >= 0)
  AND (duration_seconds IS NULL OR (duration_seconds >= 0 AND duration_seconds <= 86400))
);