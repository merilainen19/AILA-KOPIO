-- Drop unused analytics_events table that's causing security issues
DROP TABLE IF EXISTS public.analytics_events CASCADE;