-- Drop the unused conversations table to fix security error
DROP TABLE IF EXISTS public.conversations CASCADE;