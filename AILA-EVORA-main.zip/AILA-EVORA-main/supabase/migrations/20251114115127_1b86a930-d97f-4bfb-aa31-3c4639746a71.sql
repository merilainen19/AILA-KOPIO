-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS validate_analytics_event_before_insert ON public.analytics_events;

-- Create or replace the validation function
CREATE OR REPLACE FUNCTION public.validate_analytics_event_data()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Ensure event_data is not null and is a valid JSON object
  IF NEW.event_data IS NULL THEN
    NEW.event_data = '{}'::jsonb;
  END IF;
  
  -- Limit the size of event_data to prevent abuse (max 10KB)
  IF length(NEW.event_data::text) > 10240 THEN
    RAISE EXCEPTION 'event_data exceeds maximum allowed size of 10KB';
  END IF;
  
  -- Ensure event_type is not empty and has reasonable length
  IF NEW.event_type IS NULL OR length(NEW.event_type) = 0 THEN
    RAISE EXCEPTION 'event_type cannot be empty';
  END IF;
  
  IF length(NEW.event_type) > 255 THEN
    RAISE EXCEPTION 'event_type exceeds maximum length of 255 characters';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recreate trigger to validate data before insert
CREATE TRIGGER validate_analytics_event_before_insert
  BEFORE INSERT ON public.analytics_events
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_analytics_event_data();

-- Add a comment to document the security measure
COMMENT ON FUNCTION public.validate_analytics_event_data() IS 'Validates and sanitizes analytics event data to prevent malicious data injection. Limits event_data size to 10KB and validates event_type format.';