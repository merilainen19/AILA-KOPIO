-- Drop the insecure update policy
DROP POLICY IF EXISTS "Can only update recent sessions" ON public.analytics_sessions;

-- Sessions can only be created by anyone, but never updated directly
-- Updates should happen via edge functions with proper validation
-- This prevents anyone from tampering with analytics data