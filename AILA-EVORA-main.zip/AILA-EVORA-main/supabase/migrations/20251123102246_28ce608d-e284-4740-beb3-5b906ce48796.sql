-- Fix security warnings for analytics tables

-- 1. Drop existing overly permissive insert policy
DROP POLICY IF EXISTS "Anyone can insert sessions" ON public.analytics_sessions;

-- 2. Create more restrictive policy that validates session data
-- This allows inserts but adds basic validation to prevent abuse
CREATE POLICY "Allow validated session inserts"
ON public.analytics_sessions
FOR INSERT
WITH CHECK (
  -- Ensure session_id is provided
  session_id IS NOT NULL
  -- Ensure started_at is reasonable (not in future, not too old)
  AND started_at <= now()
  AND started_at >= now() - interval '24 hours'
  -- Ensure numeric fields are reasonable
  AND COALESCE(total_messages, 0) >= 0
  AND COALESCE(total_messages, 0) <= 1000
  AND COALESCE(user_messages, 0) >= 0
  AND COALESCE(bot_messages, 0) >= 0
  AND COALESCE(duration_seconds, 0) >= 0
  AND COALESCE(duration_seconds, 0) <= 86400 -- max 24 hours
);

-- 3. Update page_visits policy with similar validation
DROP POLICY IF EXISTS "Anyone can insert page visits" ON public.page_visits;

CREATE POLICY "Allow validated page visit inserts"
ON public.page_visits
FOR INSERT
WITH CHECK (
  -- Ensure action is not empty and has reasonable length
  action IS NOT NULL
  AND length(action) > 0
  AND length(action) <= 100
  -- Ensure visited_at is reasonable
  AND visited_at <= now()
  AND visited_at >= now() - interval '1 hour'
);

-- 4. Add a policy to allow anonymous updates to their own sessions
-- This allows the widget to update session data as conversation progresses
CREATE POLICY "Allow session updates by session_id"
ON public.analytics_sessions
FOR UPDATE
USING (true)
WITH CHECK (
  -- Validate updated values are reasonable
  COALESCE(total_messages, 0) >= 0
  AND COALESCE(total_messages, 0) <= 1000
  AND COALESCE(user_messages, 0) >= 0
  AND COALESCE(bot_messages, 0) >= 0
  AND COALESCE(duration_seconds, 0) >= 0
  AND COALESCE(duration_seconds, 0) <= 86400
  AND (ended_at IS NULL OR ended_at >= started_at)
);