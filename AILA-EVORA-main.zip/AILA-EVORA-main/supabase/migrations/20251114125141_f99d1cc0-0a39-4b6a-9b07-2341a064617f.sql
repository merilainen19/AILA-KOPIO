-- Attach validation trigger to analytics_events table
CREATE TRIGGER validate_analytics_event_data_trigger
  BEFORE INSERT ON public.analytics_events
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_analytics_event_data();