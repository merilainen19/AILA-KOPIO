import { supabase } from "@/integrations/supabase/client";

// Initialize or retrieve session ID
export const initializeSession = async (): Promise<string> => {
  let sessionId = sessionStorage.getItem('aila_session_id');
  
  if (!sessionId) {
    // Generate new session ID
    sessionId = crypto.randomUUID();
    sessionStorage.setItem('aila_session_id', sessionId);
    
    // Create session record in database
    try {
      await supabase
        .from('analytics_sessions')
        .insert({
          session_id: sessionId,
          started_at: new Date().toISOString(),
        });
    } catch (error) {
      console.debug('Session initialization failed:', error);
    }
  }
  
  return sessionId;
};

export const trackEvent = async (action: 'page_view' | 'widget_opened' | 'chat_started' | 'voice_mode_started', sessionId?: string) => {
  try {
    await (supabase as any)
      .from('page_visits')
      .insert({
        action,
        session_id: sessionId,
        user_agent: navigator.userAgent,
      });
  } catch (error) {
    // Silently fail - don't disrupt user experience
    console.debug('Analytics tracking failed:', error);
  }
};

export const updateSessionData = async (sessionId: string, data: {
  conversation_mode_used?: boolean;
  duration_seconds?: number;
  total_messages?: number;
  user_messages?: number;
  bot_messages?: number;
  ended_at?: string;
}) => {
  try {
    await supabase
      .from('analytics_sessions')
      .update(data)
      .eq('session_id', sessionId);
  } catch (error) {
    console.debug('Session update failed:', error);
  }
};

export const trackConversion = async (sessionId: string) => {
  try {
    await (supabase as any)
      .from('analytics_sessions')
      .update({ scheduled_call: true })
      .eq('session_id', sessionId);
  } catch (error) {
    console.debug('Conversion tracking failed:', error);
  }
};

// Make trackConversion globally available for website integration
if (typeof window !== 'undefined') {
  (window as any).ailaTrackConversion = () => {
    const sessionId = sessionStorage.getItem('aila_session_id');
    if (sessionId) {
      trackConversion(sessionId);
    }
  };
}
