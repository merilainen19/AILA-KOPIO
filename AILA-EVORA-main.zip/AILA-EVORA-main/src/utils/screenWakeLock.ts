export class ScreenWakeLock {
  private wakeLock: WakeLockSentinel | null = null;

  /**
   * Check if Screen Wake Lock API is supported
   */
  isSupported(): boolean {
    return 'wakeLock' in navigator;
  }

  /**
   * Request a wake lock to keep the screen on
   */
  async request(): Promise<boolean> {
    if (!this.isSupported()) {
      console.warn('Screen Wake Lock API is not supported');
      return false;
    }

    try {
      this.wakeLock = await navigator.wakeLock.request('screen');
      console.log('🔒 Screen wake lock acquired');

      // Re-request wake lock when page becomes visible again
      this.wakeLock.addEventListener('release', () => {
        console.log('🔓 Screen wake lock released');
      });

      return true;
    } catch (err) {
      console.error('Failed to acquire screen wake lock:', err);
      return false;
    }
  }

  /**
   * Release the wake lock
   */
  async release(): Promise<void> {
    if (this.wakeLock) {
      try {
        await this.wakeLock.release();
        this.wakeLock = null;
      } catch (err) {
        console.error('Failed to release screen wake lock:', err);
      }
    }
  }

  /**
   * Check if wake lock is currently active
   */
  isActive(): boolean {
    return this.wakeLock !== null && !this.wakeLock.released;
  }
}
