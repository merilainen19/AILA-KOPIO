import { supabase } from "@/integrations/supabase/client";

export class AudioRecorder {
  private stream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;

  constructor(private onAudioData: (audioData: Float32Array) => void) {}

  async start() {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 24000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      
      this.audioContext = new AudioContext({
        sampleRate: 24000,
      });
      
      this.source = this.audioContext.createMediaStreamSource(this.stream);
      this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
      
      this.processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        this.onAudioData(new Float32Array(inputData));
      };
      
      this.source.connect(this.processor);
      this.processor.connect(this.audioContext.destination);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      throw error;
    }
  }

  stop() {
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
  }
}

export class RealtimeChat {
  private pc: RTCPeerConnection | null = null;
  private dc: RTCDataChannel | null = null;
  private audioEl: HTMLAudioElement;
  private recorder: AudioRecorder | null = null;
  private localStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private isMuted: boolean = false;
  private isDisconnecting: boolean = false;

  constructor(
    private onMessage: (message: any) => void,
    private onConnectionStateChange: (state: string) => void
  ) {
    this.audioEl = document.createElement("audio");
    this.audioEl.autoplay = true;
    
    // Improve audio quality and prevent cutoffs
    this.audioEl.preload = "auto";
    
    // Append to document to ensure it stays active
    document.body.appendChild(this.audioEl);
    this.audioEl.style.display = "none";
    
    // Create audio context for better control
    this.audioContext = new AudioContext();
  }

  async init() {
    try {
      // Get ephemeral token from our Supabase Edge Function
      const { data, error } = await supabase.functions.invoke("realtime-token");
      
      if (error) throw error;
      if (!data?.client_secret?.value) {
        throw new Error("Failed to get ephemeral token");
      }

      // Check if disconnection was requested during token fetch
      if (this.isDisconnecting) {
        console.log("🎤 Connection cancelled during token fetch");
        throw new Error("Connection cancelled");
      }

      const EPHEMERAL_KEY = data.client_secret.value;

      // Create peer connection
      this.pc = new RTCPeerConnection();

      // Monitor connection state
      this.pc.onconnectionstatechange = () => {
        this.onConnectionStateChange(this.pc?.connectionState || 'disconnected');
      };

      // Set up remote audio with better handling
      this.pc.ontrack = async (e) => {
        // Ensure audio context is running
        if (this.audioContext && this.audioContext.state === 'suspended') {
          await this.audioContext.resume();
        }
        
        this.audioEl.srcObject = e.streams[0];
        
        // Force play to ensure audio starts
        try {
          await this.audioEl.play();
        } catch (error) {
          console.error('Error starting audio playback:', error);
        }
      };

      // Add local audio track
      this.localStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          sampleRate: 24000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      // Check if disconnection was requested during getUserMedia
      if (this.isDisconnecting) {
        console.log("🎤 Connection cancelled during microphone access - cleaning up immediately");
        // Clean up the microphone stream we just acquired
        this.localStream.getTracks().forEach(track => {
          track.stop();
          track.enabled = false;
        });
        this.localStream = null;
        throw new Error("Connection cancelled");
      }

      this.pc.addTrack(this.localStream.getTracks()[0]);

      // Set up data channel
      this.dc = this.pc.createDataChannel("oai-events");
      this.dc.addEventListener("message", (e) => {
        const event = JSON.parse(e.data);
        this.onMessage(event);
      });

      // Create and set local description
      const offer = await this.pc.createOffer();
      await this.pc.setLocalDescription(offer);

      // Check if disconnection was requested during offer creation
      if (this.isDisconnecting) {
        console.log("🎤 Connection cancelled during offer creation");
        throw new Error("Connection cancelled");
      }

      // Connect to OpenAI's Realtime API
      const baseUrl = "https://api.openai.com/v1/realtime";
      const model = "gpt-4o-realtime-preview-2024-12-17";
      const sdpResponse = await fetch(`${baseUrl}?model=${model}`, {
        method: "POST",
        body: offer.sdp,
        headers: {
          Authorization: `Bearer ${EPHEMERAL_KEY}`,
          "Content-Type": "application/sdp"
        },
      });

      if (!sdpResponse.ok) {
        throw new Error(`Failed to connect: ${sdpResponse.status}`);
      }

      // Check if disconnection was requested during fetch
      if (this.isDisconnecting) {
        console.log("🎤 Connection cancelled during OpenAI connection");
        throw new Error("Connection cancelled");
      }

      const answer = {
        type: "answer" as RTCSdpType,
        sdp: await sdpResponse.text(),
      };
      
      await this.pc.setRemoteDescription(answer);

      console.log("🎤 Connection established successfully");

    } catch (error) {
      console.error("Error initializing chat:", error);
      // Always clean up on error
      this.disconnect();
      throw error;
    }
  }

  private encodeAudioData(float32Array: Float32Array): string {
    const int16Array = new Int16Array(float32Array.length);
    for (let i = 0; i < float32Array.length; i++) {
      const s = Math.max(-1, Math.min(1, float32Array[i]));
      int16Array[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    
    const uint8Array = new Uint8Array(int16Array.buffer);
    let binary = '';
    const chunkSize = 0x8000;
    
    for (let i = 0; i < uint8Array.length; i += chunkSize) {
      const chunk = uint8Array.subarray(i, Math.min(i + chunkSize, uint8Array.length));
      binary += String.fromCharCode.apply(null, Array.from(chunk));
    }
    
    return btoa(binary);
  }

  toggleMute(): boolean {
    if (this.localStream) {
      const audioTrack = this.localStream.getAudioTracks()[0];
      if (audioTrack) {
        this.isMuted = !this.isMuted;
        audioTrack.enabled = !this.isMuted;
        return this.isMuted;
      }
    }
    return false;
  }

  getMutedState(): boolean {
    return this.isMuted;
  }

  stopBotSpeaking() {
    // Send cancel response event to OpenAI
    if (this.dc && this.dc.readyState === 'open') {
      this.dc.send(JSON.stringify({
        type: 'response.cancel'
      }));
    }
    
    // Stop audio playback
    if (this.audioEl) {
      this.audioEl.pause();
      this.audioEl.currentTime = 0;
    }
  }

  disconnect() {
    // Set flag FIRST to cancel any in-progress init()
    this.isDisconnecting = true;
    console.log("🎤 Disconnecting microphone and cleaning up...");
    
    this.recorder?.stop();
    
    // Stop ALL media stream tracks with extra safety
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => {
        console.log("🎤 Stopping track:", track.kind, "enabled:", track.enabled);
        track.stop();
        track.enabled = false; // Extra safety
      });
      this.localStream = null;
    }
    
    // Close data channel first
    if (this.dc) {
      this.dc.close();
      this.dc = null;
    }
    
    // Close peer connection
    if (this.pc) {
      this.pc.close();
      this.pc = null;
    }
    
    // Clean up audio element
    if (this.audioEl) {
      this.audioEl.srcObject = null;
      this.audioEl.pause();
      if (this.audioEl.parentNode) {
        this.audioEl.parentNode.removeChild(this.audioEl);
      }
    }
    
    // Close audio context
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
    
    // Reset flag so the instance can be reused if needed
    this.isDisconnecting = false;
    
    console.log("🎤 Microphone disconnected and cleaned up");
  }
}
