import { ChatWidget } from "@/components/ChatWidget";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { trackEvent } from "@/utils/analytics";

const Index = () => {
  const location = useLocation();
  const isEmbeddedWidget =
    typeof window !== "undefined" &&
    new URLSearchParams(location.search).get("embed") === "1";

  useEffect(() => {
    trackEvent("page_view");
  }, []);

  return (
    <div className={isEmbeddedWidget ? "min-h-screen bg-transparent" : "min-h-screen bg-background"}>
      <ChatWidget />
    </div>
  );
};

export default Index;
