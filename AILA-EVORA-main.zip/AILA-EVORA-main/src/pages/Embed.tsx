import { ChatWidget } from "@/components/ChatWidget";

const Embed = () => {
  return (
    <div className="h-screen w-screen overflow-hidden">
      <ChatWidget isEmbedded={true} />
    </div>
  );
};

export default Embed;
