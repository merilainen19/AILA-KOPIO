import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { LogOut, BarChart3, MessageSquare, Clock, Users, MousePointer, TrendingUp, Calendar as CalendarIcon, Mic, Type, ArrowRight, PhoneCall, Star } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, subDays, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts";

interface AnalyticsData {
  totalSessions: number;
  totalMessages: number;
  avgDuration: number;
  conversationModeUsage: number;
  totalVisitors: number;
  totalWidgetOpens: number;
  totalChatStarts: number;
  totalVoiceModeStarts: number;
  engagementRate: number;
  chatModeSessions: number;
  voiceModeSessions: number;
  avgChatDuration: number;
  avgVoiceDuration: number;
  avgMessagesPerSession: number;
  totalConversions: number;
  conversionRate: number;
  textConversions: number;
  voiceConversions: number;
  avgMessagesBeforeConversion: number;
  avgDurationBeforeConversion: number;
  quickExitRate: number;
  repeatUserRate: number;
  sessionQualityScore: number;
}

interface RecentSession {
  id: string;
  started_at: string;
  ended_at: string | null;
  total_messages: number;
  duration_seconds: number | null;
  conversation_mode_used: boolean;
  scheduled_call?: boolean;
}

interface RecentVisit {
  id: string;
  visited_at: string;
  action: string;
}

type DateFilter = 'today' | 'week' | 'month' | 'custom' | 'all';
type DetailView = 'sessions' | 'messages' | 'duration' | 'modes' | 'engagement' | 'conversions' | 'satisfaction' | null;

const Analytics = () => {
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [dateFilter, setDateFilter] = useState<DateFilter>('all');
  const [customStartDate, setCustomStartDate] = useState<Date | undefined>();
  const [customEndDate, setCustomEndDate] = useState<Date | undefined>();
  const [detailView, setDetailView] = useState<DetailView>(null);
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalSessions: 0,
    totalMessages: 0,
    avgDuration: 0,
    conversationModeUsage: 0,
    totalVisitors: 0,
    totalWidgetOpens: 0,
    totalChatStarts: 0,
    totalVoiceModeStarts: 0,
    engagementRate: 0,
    chatModeSessions: 0,
    voiceModeSessions: 0,
    avgChatDuration: 0,
    avgVoiceDuration: 0,
    avgMessagesPerSession: 0,
    totalConversions: 0,
    conversionRate: 0,
    textConversions: 0,
    voiceConversions: 0,
    avgMessagesBeforeConversion: 0,
    avgDurationBeforeConversion: 0,
    quickExitRate: 0,
    repeatUserRate: 0,
    sessionQualityScore: 0,
  });
  const [recentSessions, setRecentSessions] = useState<RecentSession[]>([]);
  const [recentVisits, setRecentVisits] = useState<RecentVisit[]>([]);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    checkAdminAndLoadData();
  }, [dateFilter, customStartDate, customEndDate]);

  const getDateRange = () => {
    const now = new Date();
    let startDate: Date;
    let endDate: Date = endOfDay(now);

    switch (dateFilter) {
      case 'today':
        startDate = startOfDay(now);
        break;
      case 'week':
        startDate = startOfWeek(now);
        endDate = endOfWeek(now);
        break;
      case 'month':
        startDate = startOfMonth(now);
        endDate = endOfMonth(now);
        break;
      case 'custom':
        if (customStartDate && customEndDate) {
          startDate = startOfDay(customStartDate);
          endDate = endOfDay(customEndDate);
        } else {
          return null;
        }
        break;
      default:
        return null;
    }

    return { startDate: startDate.toISOString(), endDate: endDate.toISOString() };
  };

  const checkAdminAndLoadData = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      // Check if user is admin
      const { data: roleData, error: roleError } = await (supabase as any)
        .from("user_roles")
        .select("role")
        .eq("user_id", session.user.id)
        .eq("role", "admin")
        .single();

      if (roleError || !roleData) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to view this page.",
        });
        navigate("/");
        return;
      }

      setIsAdmin(true);

      // Load analytics data with date filtering
      const dateRange = getDateRange();
      
      let sessionsQuery = (supabase as any)
        .from("analytics_sessions")
        .select("*");
      
      if (dateRange) {
        sessionsQuery = sessionsQuery
          .gte("started_at", dateRange.startDate)
          .lte("started_at", dateRange.endDate);
      }
      
      sessionsQuery = sessionsQuery.order("started_at", { ascending: false });
      
      const { data: sessions, error: sessionsError } = await sessionsQuery;

      if (sessionsError) throw sessionsError;

      // Load page visits data with date filtering
      let visitsQuery = (supabase as any)
        .from("page_visits")
        .select("*");
      
      if (dateRange) {
        visitsQuery = visitsQuery
          .gte("visited_at", dateRange.startDate)
          .lte("visited_at", dateRange.endDate);
      }
      
      visitsQuery = visitsQuery.order("visited_at", { ascending: false });
      
      const { data: visits, error: visitsError } = await visitsQuery;

      if (visitsError) throw visitsError;

      if (sessions && visits) {
        const totalSessions = sessions.length;
        const totalMessages = sessions.reduce((sum: number, s: any) => sum + (s.total_messages || 0), 0);
        const totalDuration = sessions.reduce((sum: number, s: any) => sum + (s.duration_seconds || 0), 0);
        const avgDuration = totalSessions > 0 ? Math.round(totalDuration / totalSessions) : 0;
        const conversationModeUsage = sessions.filter((s: any) => s.conversation_mode_used).length;
        
        // Mode-specific calculations
        const chatModeSessions = totalSessions - conversationModeUsage;
        const voiceModeSessions = conversationModeUsage;
        
        const chatSessions = sessions.filter((s: any) => !s.conversation_mode_used);
        const voiceSessions = sessions.filter((s: any) => s.conversation_mode_used);
        
        const chatDuration = chatSessions.reduce((sum: number, s: any) => sum + (s.duration_seconds || 0), 0);
        const voiceDuration = voiceSessions.reduce((sum: number, s: any) => sum + (s.duration_seconds || 0), 0);
        
        const avgChatDuration = chatSessions.length > 0 ? Math.round(chatDuration / chatSessions.length) : 0;
        const avgVoiceDuration = voiceSessions.length > 0 ? Math.round(voiceDuration / voiceSessions.length) : 0;
        const avgMessagesPerSession = totalSessions > 0 ? Math.round(totalMessages / totalSessions) : 0;
        
        const totalVisitors = visits.filter((v: any) => v.action === 'page_view').length;
        const totalWidgetOpens = visits.filter((v: any) => v.action === 'widget_opened').length;
        const totalChatStarts = visits.filter((v: any) => v.action === 'chat_started').length;
        const totalVoiceModeStarts = visits.filter((v: any) => v.action === 'voice_mode_started').length;
        const engagementRate = totalVisitors > 0 ? Math.round((totalWidgetOpens / totalVisitors) * 100) : 0;

        // Conversion tracking
        const conversions = sessions.filter((s: any) => s.scheduled_call === true);
        const totalConversions = conversions.length;
        const conversionRate = totalSessions > 0 ? Math.round((totalConversions / totalSessions) * 100) : 0;
        const textConversions = conversions.filter((s: any) => !s.conversation_mode_used).length;
        const voiceConversions = conversions.filter((s: any) => s.conversation_mode_used).length;
        
        const conversionMessages = conversions.reduce((sum: number, s: any) => sum + (s.total_messages || 0), 0);
        const avgMessagesBeforeConversion = totalConversions > 0 ? Math.round(conversionMessages / totalConversions) : 0;
        
        const conversionDuration = conversions.reduce((sum: number, s: any) => sum + (s.duration_seconds || 0), 0);
        const avgDurationBeforeConversion = totalConversions > 0 ? Math.round(conversionDuration / totalConversions) : 0;

        // Satisfaction indicators
        const quickExits = sessions.filter((s: any) => (s.duration_seconds || 0) < 30).length;
        const quickExitRate = totalSessions > 0 ? Math.round((quickExits / totalSessions) * 100) : 0;
        
        // Track unique session IDs to estimate repeat users
        const uniqueSessionIds = new Set(sessions.map((s: any) => s.session_id));
        const repeatUserRate = totalSessions > uniqueSessionIds.size ? 
          Math.round(((totalSessions - uniqueSessionIds.size) / totalSessions) * 100) : 0;
        
        // Session quality score (0-100) based on multiple factors
        const engagedSessions = sessions.filter((s: any) => 
          (s.duration_seconds || 0) >= 30 && 
          (s.total_messages || 0) >= 2
        ).length;
        const sessionQualityScore = totalSessions > 0 ? 
          Math.round((engagedSessions / totalSessions) * 100) : 0;

        setAnalytics({
          totalSessions,
          totalMessages,
          avgDuration,
          conversationModeUsage,
          totalVisitors,
          totalWidgetOpens,
          totalChatStarts,
          totalVoiceModeStarts,
          engagementRate,
          chatModeSessions,
          voiceModeSessions,
          avgChatDuration,
          avgVoiceDuration,
          avgMessagesPerSession,
          totalConversions,
          conversionRate,
          textConversions,
          voiceConversions,
          avgMessagesBeforeConversion,
          avgDurationBeforeConversion,
          quickExitRate,
          repeatUserRate,
          sessionQualityScore,
        });
        
        // Set recent activity
        setRecentSessions(sessions.slice(0, 10));
        setRecentVisits(visits.slice(0, 10));
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col gap-4 mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Analytics Dashboard</h1>
              <p className="text-muted-foreground mt-1">Chat bot performance metrics</p>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>

          {/* Date Filter Controls */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-sm font-medium mr-2">Time Period:</span>
                <Button
                  variant={dateFilter === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDateFilter('all')}
                >
                  All Time
                </Button>
                <Button
                  variant={dateFilter === 'today' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDateFilter('today')}
                >
                  Today
                </Button>
                <Button
                  variant={dateFilter === 'week' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDateFilter('week')}
                >
                  This Week
                </Button>
                <Button
                  variant={dateFilter === 'month' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDateFilter('month')}
                >
                  This Month
                </Button>
                
                <div className="flex gap-2 items-center ml-2">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className={cn(
                          "justify-start text-left font-normal",
                          !customStartDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {customStartDate ? format(customStartDate, "PPP") : "Start Date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={customStartDate}
                        onSelect={(date) => {
                          setCustomStartDate(date);
                          if (date && customEndDate) {
                            setDateFilter('custom');
                          }
                        }}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>

                  <span className="text-sm text-muted-foreground">to</span>

                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className={cn(
                          "justify-start text-left font-normal",
                          !customEndDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {customEndDate ? format(customEndDate, "PPP") : "End Date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={customEndDate}
                        onSelect={(date) => {
                          setCustomEndDate(date);
                          if (date && customStartDate) {
                            setDateFilter('custom');
                          }
                        }}
                        disabled={(date) => customStartDate ? date < customStartDate : false}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setDetailView('sessions')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AILA Sessions</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalSessions}</div>
              <p className="text-xs text-muted-foreground">Total conversations with AILA</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                <span>View details</span>
                <ArrowRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setDetailView('messages')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Messages</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalMessages}</div>
              <p className="text-xs text-muted-foreground">Avg {analytics.avgMessagesPerSession} per session</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                <span>View breakdown</span>
                <ArrowRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setDetailView('duration')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Session Duration</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.avgDuration}s</div>
              <p className="text-xs text-muted-foreground">Average time with AILA</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                <span>Compare modes</span>
                <ArrowRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setDetailView('modes')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Interaction Modes</CardTitle>
              <Mic className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className="text-2xl font-bold">{analytics.conversationModeUsage}</div>
                <span className="text-sm text-muted-foreground">voice</span>
              </div>
              <p className="text-xs text-muted-foreground">{analytics.chatModeSessions} used text chat</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                <span>Mode comparison</span>
                <ArrowRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Visitors</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalVisitors}</div>
              <p className="text-xs text-muted-foreground">Unique page views</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AILA Widget Opens</CardTitle>
              <MousePointer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalWidgetOpens}</div>
              <p className="text-xs text-muted-foreground">Times AILA was opened</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setDetailView('engagement')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Engagement Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.engagementRate}%</div>
              <p className="text-xs text-muted-foreground">Visitors who tried AILA</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                <span>View funnel</span>
                <ArrowRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setDetailView('conversions')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Call Conversions</CardTitle>
              <PhoneCall className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalConversions}</div>
              <p className="text-xs text-muted-foreground">{analytics.conversionRate}% conversion rate</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                <span>View details</span>
                <ArrowRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setDetailView('satisfaction')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Session Quality</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.sessionQualityScore}%</div>
              <p className="text-xs text-muted-foreground">Engaged sessions (30s+ & 2+ msgs)</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                <span>View insights</span>
                <ArrowRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Visual Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
          {/* Mode Usage Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>AILA Interaction Modes</CardTitle>
              <CardDescription>Voice vs Text usage distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Voice Conversation', value: analytics.voiceModeSessions, color: 'hsl(var(--primary))' },
                      { name: 'Text Chat', value: analytics.chatModeSessions, color: 'hsl(var(--muted))' }
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {[
                      { name: 'Voice Conversation', value: analytics.voiceModeSessions, color: 'hsl(var(--primary))' },
                      { name: 'Text Chat', value: analytics.chatModeSessions, color: 'hsl(var(--muted))' }
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Duration Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>Average Session Duration</CardTitle>
              <CardDescription>Time spent with AILA by mode</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={[
                    { name: 'Text Chat', duration: analytics.avgChatDuration, fill: 'hsl(var(--muted))' },
                    { name: 'Voice Mode', duration: analytics.avgVoiceDuration, fill: 'hsl(var(--primary))' }
                  ]}
                >
                  <XAxis dataKey="name" />
                  <YAxis label={{ value: 'Seconds', angle: -90, position: 'insideLeft' }} />
                  <Tooltip />
                  <Bar dataKey="duration" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]}>
                    {[
                      { name: 'Text Chat', duration: analytics.avgChatDuration, fill: 'hsl(var(--muted))' },
                      { name: 'Voice Mode', duration: analytics.avgVoiceDuration, fill: 'hsl(var(--primary))' }
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Engagement Funnel */}
          <Card>
            <CardHeader>
              <CardTitle>User Engagement Funnel</CardTitle>
              <CardDescription>From visit to call scheduling</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart
                  data={[
                    { stage: 'Visitors', count: analytics.totalVisitors, fill: 'hsl(var(--muted))' },
                    { stage: 'Opened AILA', count: analytics.totalWidgetOpens, fill: 'hsl(var(--accent))' },
                    { stage: 'Started Chat', count: analytics.totalChatStarts, fill: 'hsl(var(--primary))' },
                    { stage: 'Used Voice', count: analytics.totalVoiceModeStarts, fill: 'hsl(var(--chart-1))' },
                    { stage: 'Scheduled Call', count: analytics.totalConversions, fill: 'hsl(var(--chart-2))' }
                  ]}
                  layout="vertical"
                >
                  <XAxis type="number" />
                  <YAxis dataKey="stage" type="category" width={120} />
                  <Tooltip />
                  <Bar dataKey="count" radius={[0, 8, 8, 0]}>
                    {[
                      { stage: 'Visitors', count: analytics.totalVisitors, fill: 'hsl(var(--muted))' },
                      { stage: 'Opened AILA', count: analytics.totalWidgetOpens, fill: 'hsl(var(--accent))' },
                      { stage: 'Started Chat', count: analytics.totalChatStarts, fill: 'hsl(var(--primary))' },
                      { stage: 'Used Voice', count: analytics.totalVoiceModeStarts, fill: 'hsl(var(--chart-1))' },
                      { stage: 'Scheduled Call', count: analytics.totalConversions, fill: 'hsl(var(--chart-2))' }
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Session Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Session Metrics Overview</CardTitle>
              <CardDescription>Key AILA performance indicators</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={[
                    { metric: 'Sessions', value: analytics.totalSessions },
                    { metric: 'Avg Messages', value: analytics.avgMessagesPerSession },
                    { metric: 'Avg Duration (s)', value: analytics.avgDuration },
                    { metric: 'Engagement %', value: analytics.engagementRate }
                  ]}
                >
                  <XAxis dataKey="metric" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Detail View Dialog */}
        <Dialog open={detailView !== null} onOpenChange={() => setDetailView(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {detailView === 'sessions' && 'AILA Session Details'}
                {detailView === 'messages' && 'Message Breakdown'}
                {detailView === 'duration' && 'Duration Analysis'}
                {detailView === 'modes' && 'Interaction Mode Comparison'}
                {detailView === 'engagement' && 'Engagement Funnel'}
                {detailView === 'conversions' && 'Call Conversion Analysis'}
                {detailView === 'satisfaction' && 'User Satisfaction Insights'}
              </DialogTitle>
              <DialogDescription>
                Detailed analytics about how users interact with AILA
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 mt-4">
              {detailView === 'sessions' && (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Total Sessions</p>
                          <p className="text-3xl font-bold">{analytics.totalSessions}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground flex items-center gap-2">
                              <Type className="h-4 w-4" /> Text Chat Sessions
                            </p>
                            <p className="text-2xl font-bold">{analytics.chatModeSessions}</p>
                            <p className="text-xs text-muted-foreground">
                              {analytics.totalSessions > 0 ? Math.round((analytics.chatModeSessions / analytics.totalSessions) * 100) : 0}% of total
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground flex items-center gap-2">
                              <Mic className="h-4 w-4" /> Voice Conversation Sessions
                            </p>
                            <p className="text-2xl font-bold">{analytics.voiceModeSessions}</p>
                            <p className="text-xs text-muted-foreground">
                              {analytics.totalSessions > 0 ? Math.round((analytics.voiceModeSessions / analytics.totalSessions) * 100) : 0}% of total
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {detailView === 'messages' && (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Total Messages Exchanged</p>
                          <p className="text-3xl font-bold">{analytics.totalMessages}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Average Messages per Session</p>
                          <p className="text-2xl font-bold">{analytics.avgMessagesPerSession}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Users exchange an average of {analytics.avgMessagesPerSession} messages when talking to AILA
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {detailView === 'duration' && (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Overall Average Duration</p>
                          <p className="text-3xl font-bold">{analytics.avgDuration}s</p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-4 bg-muted/50 rounded-lg">
                            <p className="text-sm text-muted-foreground flex items-center gap-2">
                              <Type className="h-4 w-4" /> Text Chat Mode
                            </p>
                            <p className="text-2xl font-bold">{analytics.avgChatDuration}s</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Average session length
                            </p>
                          </div>
                          <div className="p-4 bg-muted/50 rounded-lg">
                            <p className="text-sm text-muted-foreground flex items-center gap-2">
                              <Mic className="h-4 w-4" /> Voice Mode
                            </p>
                            <p className="text-2xl font-bold">{analytics.avgVoiceDuration}s</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Average session length
                            </p>
                          </div>
                        </div>
                        {analytics.avgVoiceDuration > analytics.avgChatDuration && (
                          <p className="text-sm text-primary">
                            Voice conversations are {Math.round(((analytics.avgVoiceDuration - analytics.avgChatDuration) / analytics.avgChatDuration) * 100)}% longer on average
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {detailView === 'modes' && (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-4 border-2 border-primary rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <Mic className="h-5 w-5 text-primary" />
                              <p className="font-semibold">Voice Conversation Mode</p>
                            </div>
                            <p className="text-3xl font-bold">{analytics.voiceModeSessions}</p>
                            <p className="text-sm text-muted-foreground mt-2">
                              {analytics.totalSessions > 0 ? Math.round((analytics.voiceModeSessions / analytics.totalSessions) * 100) : 0}% of all AILA interactions
                            </p>
                            <div className="mt-3 pt-3 border-t">
                              <p className="text-xs text-muted-foreground">Avg Duration</p>
                              <p className="text-lg font-semibold">{analytics.avgVoiceDuration}s</p>
                            </div>
                          </div>
                          <div className="p-4 border-2 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <Type className="h-5 w-5" />
                              <p className="font-semibold">Text Chat Mode</p>
                            </div>
                            <p className="text-3xl font-bold">{analytics.chatModeSessions}</p>
                            <p className="text-sm text-muted-foreground mt-2">
                              {analytics.totalSessions > 0 ? Math.round((analytics.chatModeSessions / analytics.totalSessions) * 100) : 0}% of all AILA interactions
                            </p>
                            <div className="mt-3 pt-3 border-t">
                              <p className="text-xs text-muted-foreground">Avg Duration</p>
                              <p className="text-lg font-semibold">{analytics.avgChatDuration}s</p>
                            </div>
                          </div>
                        </div>
                        <div className="p-4 bg-primary/10 rounded-lg">
                          <p className="text-sm font-medium">Mode Preference</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {analytics.voiceModeSessions > analytics.chatModeSessions 
                              ? 'Users prefer Voice Conversation Mode when interacting with AILA' 
                              : 'Users prefer Text Chat Mode when interacting with AILA'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {detailView === 'engagement' && (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Engagement Funnel</p>
                        </div>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                            <span className="text-sm">Total Visitors</span>
                            <span className="text-xl font-bold">{analytics.totalVisitors}</span>
                          </div>
                          <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                            <span className="text-sm">Opened AILA Widget</span>
                            <div className="text-right">
                              <span className="text-xl font-bold">{analytics.totalWidgetOpens}</span>
                              <span className="text-xs text-muted-foreground ml-2">
                                ({analytics.engagementRate}%)
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center p-3 bg-primary/10 rounded-lg">
                            <span className="text-sm font-medium">Started Conversation</span>
                            <div className="text-right">
                              <span className="text-xl font-bold">{analytics.totalSessions}</span>
                              <span className="text-xs text-muted-foreground ml-2">
                                ({analytics.totalVisitors > 0 ? Math.round((analytics.totalSessions / analytics.totalVisitors) * 100) : 0}%)
                              </span>
                            </div>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {analytics.engagementRate}% of visitors interact with AILA
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {detailView === 'conversions' && (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Total Conversions</p>
                          <p className="text-3xl font-bold">{analytics.totalConversions}</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            {analytics.conversionRate}% of sessions led to call scheduling
                          </p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground flex items-center gap-2">
                              <Type className="h-4 w-4" /> Text Chat Conversions
                            </p>
                            <p className="text-2xl font-bold">{analytics.textConversions}</p>
                            <p className="text-xs text-muted-foreground">
                              {analytics.totalConversions > 0 ? Math.round((analytics.textConversions / analytics.totalConversions) * 100) : 0}% of conversions
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground flex items-center gap-2">
                              <Mic className="h-4 w-4" /> Voice Mode Conversions
                            </p>
                            <p className="text-2xl font-bold">{analytics.voiceConversions}</p>
                            <p className="text-xs text-muted-foreground">
                              {analytics.totalConversions > 0 ? Math.round((analytics.voiceConversions / analytics.totalConversions) * 100) : 0}% of conversions
                            </p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Avg Messages Before Conversion</p>
                            <p className="text-2xl font-bold">{analytics.avgMessagesBeforeConversion}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Avg Duration Before Conversion</p>
                            <p className="text-2xl font-bold">{analytics.avgDurationBeforeConversion}s</p>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {analytics.voiceConversions > analytics.textConversions
                            ? 'Voice mode leads to more conversions'
                            : 'Text chat leads to more conversions'}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {detailView === 'satisfaction' && (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Session Quality Score</p>
                          <p className="text-3xl font-bold">{analytics.sessionQualityScore}%</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Based on sessions with 30s+ duration and 2+ messages
                          </p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Quick Exit Rate</p>
                            <p className="text-2xl font-bold">{analytics.quickExitRate}%</p>
                            <p className="text-xs text-muted-foreground">
                              Sessions under 30 seconds
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Repeat User Rate</p>
                            <p className="text-2xl font-bold">{analytics.repeatUserRate}%</p>
                            <p className="text-xs text-muted-foreground">
                              Returning users
                            </p>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Behavioral Insights</p>
                          <ul className="list-disc list-inside text-xs text-muted-foreground mt-2 space-y-1">
                            <li>Average {analytics.avgMessagesPerSession} messages per session indicates {analytics.avgMessagesPerSession >= 4 ? 'strong' : 'moderate'} engagement</li>
                            <li>Average {analytics.avgDuration}s duration suggests {analytics.avgDuration >= 60 ? 'high' : 'moderate'} user interest</li>
                            <li>{analytics.sessionQualityScore >= 70 ? 'Majority' : 'Some'} users have meaningful interactions (quality score: {analytics.sessionQualityScore}%)</li>
                            <li>{analytics.quickExitRate < 20 ? 'Low' : 'High'} quick exit rate ({analytics.quickExitRate}%) indicates {analytics.quickExitRate < 20 ? 'effective' : 'room for improvement in'} initial engagement</li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Recent Activity Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Recent Sessions</CardTitle>
              <CardDescription>Latest chat sessions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentSessions.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No sessions yet</p>
                ) : (
                  recentSessions.map((session) => (
                    <div key={session.id} className="flex justify-between items-start p-3 bg-muted/50 rounded-lg">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">
                          {new Date(session.started_at).toLocaleString()}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {session.total_messages} messages • {session.duration_seconds || 0}s duration
                          {session.conversation_mode_used && " • Voice mode"}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest page visits and interactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentVisits.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No visits yet</p>
                ) : (
                  recentVisits.map((visit) => (
                    <div key={visit.id} className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">
                          {visit.action === 'page_view' ? 'Page View' : 'Widget Opened'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(visit.visited_at).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Analytics;