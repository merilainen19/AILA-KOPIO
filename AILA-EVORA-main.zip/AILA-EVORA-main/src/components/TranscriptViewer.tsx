import { X, ScrollText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface TranscriptViewerProps {
  isOpen: boolean;
  onClose: () => void;
  messages: Message[];
}

export const TranscriptViewer = ({ isOpen, onClose, messages }: TranscriptViewerProps) => {
  if (!isOpen) return null;

  return (
    <div className="absolute inset-0 bg-background z-10 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <ScrollText className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">Conversation Transcript</h3>
        </div>
        <Button
          onClick={onClose}
          size="icon"
          variant="ghost"
          className="h-8 w-8 rounded-full hover:bg-muted"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Transcript Content */}
      <ScrollArea className="flex-1 p-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <ScrollText className="h-12 w-12 mb-2 opacity-50" />
            <p className="text-sm">No conversation yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col gap-1 ${msg.isBot ? "items-start" : "items-end"}`}
              >
                <span className="text-xs text-muted-foreground font-medium">
                  {msg.isBot ? "Aila" : "You"}
                </span>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-2 ${
                    msg.isBot
                      ? "bg-muted text-foreground"
                      : "bg-primary text-primary-foreground"
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap break-words">{msg.text}</p>
                </div>
                <span className="text-xs text-muted-foreground">
                  {msg.timestamp.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};
