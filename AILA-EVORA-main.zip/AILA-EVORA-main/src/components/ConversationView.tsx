import { ArrowRight, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import ailaAvatar from "@/assets/aila-avatar.jpg";
import { AudioWaveform } from "@/components/AudioWaveform";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface ConversationViewProps {
  isConnecting: boolean;
  isBotSpeaking: boolean;
  isUserSpeaking: boolean;
  onExitConversationMode: () => void;
  onStopBotSpeaking: () => void;
}

export const ConversationView = ({
  isConnecting,
  isBotSpeaking,
  isUserSpeaking,
  onExitConversationMode,
  onStopBotSpeaking,
}: ConversationViewProps) => {
  const isActive = isBotSpeaking || isUserSpeaking;

  return (
    <div className="flex-1 flex flex-col relative">
      {/* Main Conversation View */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-gradient-to-b from-chat-bg to-background">
        {/* Header with button */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-end">
          <Button
            onClick={onExitConversationMode}
            variant="default"
            className="rounded-full transition-all duration-200 gap-2"
          >
            <span className="text-sm">Return to chat</span>
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>

      {/* Animated Avatar - Wrapper for positioning */}
      <div className="relative mb-12 h-40 w-40">
        {/* Bot speaking animation - prominent blue pulse */}
        {isBotSpeaking && (
          <>
            <div 
              className="absolute -inset-3 rounded-full bg-primary/25 animate-pulse"
              style={{ animationDuration: '1.5s' }} 
            />
            <div 
              className="absolute -inset-5 rounded-full bg-primary/15 animate-pulse"
              style={{ animationDuration: '2s' }} 
            />
            <div 
              className="absolute -inset-7 rounded-full bg-primary/10 animate-pulse"
              style={{ animationDuration: '2.5s' }} 
            />
          </>
        )}
        
        {/* User speaking animation - calm blue pulse */}
        {isUserSpeaking && !isBotSpeaking && (
          <>
            <div 
              className="absolute -inset-2 rounded-full bg-primary/20 animate-pulse"
              style={{ animationDuration: '2s' }} 
            />
            <div 
              className="absolute -inset-4 rounded-full bg-primary/10 animate-pulse"
              style={{ animationDuration: '2.5s' }} 
            />
          </>
        )}
        
        {/* Avatar */}
        <div className={`relative h-40 w-40 rounded-full overflow-hidden border-4 transition-all duration-300 ${
          isBotSpeaking 
            ? 'border-primary shadow-[0_0_30px_rgba(59,130,246,0.6)] scale-105' 
            : isUserSpeaking 
              ? 'border-primary shadow-lg shadow-primary/30 scale-102'
              : 'border-border'
        }`}>
          <img 
            src={ailaAvatar} 
            alt="Aila" 
            className="h-full w-full object-cover"
          />
        </div>

        {/* Status indicator */}
        {isActive && (
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-primary text-primary-foreground text-xs font-medium rounded-full animate-fade-in">
            {isUserSpeaking && "Listening..."}
            {isBotSpeaking && !isUserSpeaking && "Speaking..."}
          </div>
        )}
      </div>

      {/* Audio Waveform when bot is speaking */}
      {isBotSpeaking && (
        <div className="mb-8 animate-fade-in">
          <AudioWaveform isActive={isBotSpeaking} />
          <p className="text-center text-sm text-primary font-medium mt-2">Aila is speaking</p>
        </div>
      )}

      {/* Status Text */}
      {isConnecting ? (
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground text-sm">Connecting...</p>
        </div>
      ) : !isActive && (
        <p className="text-muted-foreground/60 text-center text-sm">
          Speak naturally - I'm listening
        </p>
      )}

      {/* Control Bar - Bottom Center */}
      {!isConnecting && isBotSpeaking && (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-background/95 backdrop-blur-sm border border-border rounded-full px-6 py-3 shadow-lg">
          {/* Stop Aila Button - Only show when bot is speaking */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                onClick={onStopBotSpeaking}
                size="lg"
                variant="outline"
                className="h-12 w-12 rounded-full hover:bg-destructive hover:text-destructive-foreground hover:border-destructive transition-all duration-200"
              >
                <Square className="h-6 w-6 fill-current" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top" className="bg-foreground/90 text-background rounded-lg px-3 py-1.5">
              <p className="text-sm">Stop Aila</p>
            </TooltipContent>
          </Tooltip>
        </div>
      )}
    </div>
    </div>
  );
};
