import { Avatar } from "@/components/ui/avatar";
import ailaAvatar from "@/assets/aila-avatar.jpg";

interface ChatMessageProps {
  message: string;
  isBot: boolean;
  isTyping?: boolean;
  isSpeaking?: boolean;
}

export const ChatMessage = ({ message, isBot, isTyping = false, isSpeaking = false }: ChatMessageProps) => {
  return (
    <div className={`flex gap-3 mb-4 ${isBot ? 'justify-start' : 'justify-end'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
      {isBot && (
        <Avatar className="h-8 w-8 shrink-0">
          <img 
            src={ailaAvatar} 
            alt="Aila" 
            className="h-full w-full object-cover rounded-full"
          />
        </Avatar>
      )}
      <div
        className={`max-w-[80%] rounded-2xl px-4 py-2.5 transition-all duration-300 ease-in-out ${
          isBot
            ? 'bg-chat-botBubble text-chat-botText rounded-tl-none shadow-sm'
            : 'bg-chat-userBubble text-chat-userText rounded-tr-none'
        }`}
      >
        {isTyping ? (
          <div className="flex gap-1 py-1">
            <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        ) : (
          <p className="text-sm leading-relaxed transition-opacity duration-300 ease-in-out">{message}</p>
        )}
      </div>
    </div>
  );
};
