import { useState, useEffect, useRef } from "react";
import { X, MessageCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { ChatMessage } from "@/components/ChatMessage";
import { ChatInput } from "@/components/ChatInput";
import { ConversationView } from "@/components/ConversationView";
import { MicPermissionDialog } from "@/components/MicPermissionDialog";
import { toast } from "sonner";
import flLogo from "@/assets/fl-logo-new.png";
import { WelcomeBubble } from "@/components/WelcomeBubble";
import { RealtimeChat } from "@/utils/RealtimeAudio";
import { ScreenWakeLock } from "@/utils/screenWakeLock";
import { useVisualViewport } from "@/hooks/useVisualViewport";
import { useIsMobile } from "@/hooks/use-mobile";
import { trackEvent, initializeSession } from "@/utils/analytics";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatWidgetProps {
  isEmbedded?: boolean;
}

export const ChatWidget = ({ isEmbedded = false }: ChatWidgetProps) => {
  const [isOpen, setIsOpen] = useState(isEmbedded);
  const [isConversationMode, setIsConversationMode] = useState(false);
  const [showPermissionDialog, setShowPermissionDialog] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]); // Basic chat messages
  const [isTyping, setIsTyping] = useState(false);
  const [focusInputTrigger, setFocusInputTrigger] = useState(0);
  const [inputMessage, setInputMessage] = useState("");
  const [isConnecting, setIsConnecting] = useState(false);
  const [isBotSpeaking, setIsBotSpeaking] = useState(false);
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const realtimeChatRef = useRef<RealtimeChat | null>(null);
  const wakeLockRef = useRef<ScreenWakeLock>(new ScreenWakeLock());
  
  // Track visual viewport for mobile keyboard handling
  const { keyboardHeight, isKeyboardOpen } = useVisualViewport();
  const isMobile = useIsMobile();

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "end"
      });
    }, 0);
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Focus input when chat opens (desktop only)
  useEffect(() => {
    if ((isOpen || isEmbedded) && !isMobile) {
      setFocusInputTrigger(prev => prev + 1);
    }
  }, [isOpen, isEmbedded, isMobile]);

  // Focus input when bot finishes typing (desktop only)
  useEffect(() => {
    if (!isTyping && messages.length > 0 && !isMobile) {
      setFocusInputTrigger(prev => prev + 1);
    }
  }, [isTyping, messages.length, isMobile]);

  // Initial welcome message when opened
  useEffect(() => {
    if ((isOpen || isEmbedded) && messages.length === 0) {
      const welcomeMessage: Message = {
        id: "welcome",
        text: "Hi! I'm Aila, Finnish Leads' virtual assistant. I'm here to help you explore our services and answer your questions. Switch on Conversation Mode below to talk with me in real time!",
        isBot: true,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, isEmbedded, messages.length]);

  // Manage body scroll when chat is open (prevent page scroll on mobile)
  useEffect(() => {
    if (isOpen || isEmbedded) {
      if (!isEmbedded) {
        document.body.style.overflow = 'hidden';
      }
      
      // Initialize session and track event
      initializeSession().then(sessionId => {
        trackEvent('widget_opened', sessionId);
      });
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      if (!isEmbedded) {
        document.body.style.overflow = '';
      }
    };
  }, [isOpen, isEmbedded]);

  // Cleanup microphone and wake lock when chat closes or unmounts
  useEffect(() => {
    return () => {
      if (realtimeChatRef.current) {
        console.log("🎤 Cleaning up microphone on unmount/close");
        realtimeChatRef.current.disconnect();
        realtimeChatRef.current = null;
      }
      wakeLockRef.current.release();
    };
  }, [isOpen]);

  const streamBotResponse = async (userMessage: string) => {
    abortControllerRef.current = new AbortController();
    const signal = abortControllerRef.current.signal;
    
    setIsTyping(true);
    
    try {
      // Use message history
      const conversationHistory = messages.map(msg => ({
        role: msg.isBot ? 'assistant' : 'user',
        content: msg.text
      }));
      
      conversationHistory.push({
        role: 'user',
        content: userMessage
      });

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ messages: conversationHistory }),
          signal,
        }
      );

      if (!response.ok) {
        throw new Error('Failed to get response from AI');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let botMessageId = Date.now().toString();
      
      if (!reader) {
        throw new Error('No reader available');
      }

      let textBuffer = '';
      let streamDone = false;

      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        
        textBuffer += decoder.decode(value, { stream: true });

        // Process line-by-line as data arrives
        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);

          if (line.endsWith("\r")) line = line.slice(0, -1);   // handle CRLF
          if (line.startsWith(":") || line.trim() === "") continue; // SSE comments/keepalive
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") {
            streamDone = true;
            break;
          }

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              accumulatedText += content;
            }
          } catch {
            // Incomplete JSON split across chunks: put it back and wait for more data
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }

      // Final flush in case remaining buffered lines arrived without trailing newline
      if (textBuffer.trim()) {
        for (let raw of textBuffer.split("\n")) {
          if (!raw) continue;
          if (raw.endsWith("\r")) raw = raw.slice(0, -1);
          if (raw.startsWith(":") || raw.trim() === "") continue;
          if (!raw.startsWith("data: ")) continue;
          const jsonStr = raw.slice(6).trim();
          if (jsonStr === "[DONE]") continue;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) accumulatedText += content;
          } catch { /* ignore partial leftovers */ }
        }
      }
      
      // Add the complete message
      if (accumulatedText) {
        setMessages(prev => [...prev, {
          id: botMessageId,
          text: accumulatedText,
          isBot: true,
          timestamp: new Date()
        }]);
      }
      
      setIsTyping(false);
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        console.log('Bot response cancelled by user');
      } else {
        console.error('Error in bot response:', error);
        toast.error('Failed to get AI response', {
          description: 'Please try again'
        });
      }
      setIsTyping(false);
    } finally {
      abortControllerRef.current = null;
    }
  };
  const handleSendMessage = async (text: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      isBot: false,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    await streamBotResponse(text);
  };

  const handleConversationModeToggle = async () => {
    const newMode = !isConversationMode;
    
    if (newMode) {
      // Check if user already granted permission in this session
      const hasGrantedPermission = sessionStorage.getItem('mic-permission-granted');
      
      if (hasGrantedPermission === 'true') {
        // Skip dialog and start directly
        await handlePermissionAccept();
      } else {
        // Show permission dialog first
        setShowPermissionDialog(true);
      }
    } else {
      // Immediately stop all voice activity states
      setIsBotSpeaking(false);
      setIsUserSpeaking(false);
      setIsConnecting(false);
      
      // Disconnect and cleanup realtime connection
      if (realtimeChatRef.current) {
        realtimeChatRef.current.disconnect();
        realtimeChatRef.current = null;
      }
      
      // Release wake lock
      wakeLockRef.current.release();
      
      // Update mode state
      setIsConversationMode(false);
    }
  };

  const handlePermissionAccept = async () => {
    setShowPermissionDialog(false);
    
    // Always create a NEW instance to avoid stale state
    if (realtimeChatRef.current) {
      realtimeChatRef.current.disconnect();
      realtimeChatRef.current = null;
    }
    
    // Store permission in session storage
    sessionStorage.setItem('mic-permission-granted', 'true');
    
    setIsConversationMode(true);
    
    // Track voice mode start
    const sessionId = sessionStorage.getItem('aila_session_id');
    if (sessionId) {
      trackEvent('voice_mode_started', sessionId);
    }
    
    // Initialize WebRTC connection
    setIsConnecting(true);
    try {
      realtimeChatRef.current = new RealtimeChat(
        (event) => handleRealtimeEvent(event),
        (state) => {}
      );
      await realtimeChatRef.current.init();
      setIsConnecting(false);
      
      // Request wake lock to keep screen on during conversation
      await wakeLockRef.current.request();
    } catch (error) {
      console.error('Failed to start conversation:', error);
      setIsConnecting(false);
      setIsConversationMode(false);
      toast.error("Failed to start voice conversation", {
        description: "Please try again"
      });
    }
  };

  const handlePermissionCancel = () => {
    setShowPermissionDialog(false);
  };

  const handleRealtimeEvent = (event: any) => {
    switch (event.type) {
      case 'input_audio_buffer.speech_started':
        setIsUserSpeaking(true);
        break;
      case 'input_audio_buffer.speech_stopped':
        setIsUserSpeaking(false);
        break;
      case 'response.audio.delta':
        setIsBotSpeaking(true);
        break;
      case 'response.audio.done':
        setIsBotSpeaking(false);
        break;
      case 'response.done':
        setIsBotSpeaking(false);
        break;
      case 'error':
        console.error('Realtime API error:', event);
        toast.error('Voice conversation error');
      break;
    }
  };

  const handleRefreshConversation = () => {
    realtimeChatRef.current?.disconnect();
    setIsBotSpeaking(false);
    setIsUserSpeaking(false);
    
    // Reinitialize the connection
    setIsConnecting(true);
    setTimeout(async () => {
      try {
        realtimeChatRef.current = new RealtimeChat(
          (event) => handleRealtimeEvent(event),
          (state) => {}
        );
        await realtimeChatRef.current.init();
        setIsConnecting(false);
      } catch (error) {
        console.error('Failed to restart conversation:', error);
        setIsConnecting(false);
        toast.error("Failed to start new conversation");
      }
    }, 100);
  };

  const handleRefreshBasicChat = () => {
    setMessages([]);
    setInputMessage("");
    setIsTyping(false);
  };

  const handleToggleMute = () => {
    if (realtimeChatRef.current) {
      const muted = realtimeChatRef.current.toggleMute();
      setIsMicMuted(muted);
    }
  };

  const handleStopBotSpeaking = () => {
    if (realtimeChatRef.current) {
      realtimeChatRef.current.stopBotSpeaking();
      setIsBotSpeaking(false);
    }
  };

  const handleStopBot = () => {
    // Immediately abort the ongoing response
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    
    // Immediate state reset
    setIsTyping(false);
    
    // Focus input after stopping
    setFocusInputTrigger(prev => prev + 1);
  };

  const handleClose = () => {
    if (!isEmbedded) {
      setIsOpen(false);
    }
    
    // If we're in an iframe, notify parent window
    if (window.self !== window.top) {
      window.parent.postMessage('aila-close-chat', '*');
    }
  };
  return <>
      {/* Microphone Permission Dialog */}
      <MicPermissionDialog 
        isOpen={showPermissionDialog}
        onAccept={handlePermissionAccept}
        onCancel={handlePermissionCancel}
      />

      {/* Welcome Bubble - Only show when not embedded */}
      {!isEmbedded && !isOpen && <WelcomeBubble 
        onOpen={() => {
          localStorage.setItem('ailaBubbleShown', 'true');
          setIsOpen(true);
        }} 
        onDismiss={() => {
          // Bubble dismissed, permanently hidden
        }}
      />}

      {/* Chat Widget */}
      {(isOpen || isEmbedded) && <div 
        className={isEmbedded 
          ? "w-full h-full bg-card flex flex-col border-0" 
          : "fixed bottom-20 right-2 left-2 sm:left-auto sm:right-4 md:right-6 sm:w-[360px] h-[520px] max-h-[80vh] bg-card rounded-2xl shadow-2xl flex flex-col border border-border z-50 animate-in slide-in-from-bottom-4 duration-300"
        }
        style={!isEmbedded ? {
          bottom: isKeyboardOpen ? '20px' : undefined,
          transition: 'bottom 0.3s ease-out',
        } : undefined}
      >
          {/* Header */}
          <div className={isEmbedded 
            ? "flex items-center justify-between px-4 py-3 border-b border-border bg-primary"
            : "flex items-center justify-between px-4 py-3 border-b border-border bg-primary rounded-t-2xl"
          }>
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full overflow-hidden shrink-0">
                <img src={flLogo} alt="FinnishLeads" className="h-full w-full object-cover" />
              </div>
              <h3 className="text-lg font-normal text-primary-foreground">Aila</h3>
            </div>
            <div className="flex items-center gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={handleRefreshBasicChat}
                    className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="bg-foreground/90 text-background rounded-lg px-3 py-1.5">
                  <p className="text-sm">Start new conversation</p>
                </TooltipContent>
              </Tooltip>
              {!isEmbedded && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={handleClose}
                      className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom" className="bg-foreground/90 text-background rounded-lg px-3 py-1.5">
                    <p className="text-sm">Close chat</p>
                  </TooltipContent>
                </Tooltip>
              )}
            </div>
          </div>

          {/* Conversation Mode View */}
            {isConversationMode ? (
              <ConversationView 
                isConnecting={isConnecting}
                isBotSpeaking={isBotSpeaking}
                isUserSpeaking={isUserSpeaking}
                onExitConversationMode={handleConversationModeToggle}
                onStopBotSpeaking={handleStopBotSpeaking}
              />
          ) : (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto px-4 py-4 bg-chat-bg scrollbar-thin">
                {messages.map((msg, index) => {
                  const isLastBotMessage = msg.isBot && index === messages.length - 1;
                  const botIsSpeaking = isLastBotMessage && isTyping;
                  return (
                    <ChatMessage 
                      key={msg.id} 
                      message={msg.text} 
                      isBot={msg.isBot} 
                      isSpeaking={botIsSpeaking}
                    />
                  );
                })}
                {isTyping && <ChatMessage message="" isBot={true} isTyping={true} isSpeaking={true} />}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className={isEmbedded ? "" : "rounded-b-2xl"}>
                <ChatInput 
                  onSendMessage={handleSendMessage} 
                  disabled={isTyping} 
                  onConversationModeToggle={handleConversationModeToggle}
                  isConversationMode={isConversationMode}
                  onStopBot={handleStopBot} 
                  isBotActive={isTyping} 
                  shouldFocusInput={focusInputTrigger > 0}
                  message={inputMessage}
                  onMessageChange={setInputMessage}
                />
              </div>
            </>
          )}
        </div>}

      {/* Trigger Button - Only show when chat is closed and not embedded */}
      {!isEmbedded && !isOpen && (
        <Button 
          onClick={() => setIsOpen(true)}
          className="fixed right-2 sm:right-4 md:right-6 h-14 w-14 rounded-full shadow-2xl bg-primary hover:bg-primary/90 z-50 transition-transform hover:scale-110"
          style={{
            bottom: isKeyboardOpen ? '90px' : '16px',
            transition: 'bottom 0.3s ease-out',
          }}
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      )}
    </>;
};