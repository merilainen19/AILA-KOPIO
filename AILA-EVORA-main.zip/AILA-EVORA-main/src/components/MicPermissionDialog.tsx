import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Mic } from "lucide-react";

interface MicPermissionDialogProps {
  isOpen: boolean;
  onAccept: () => void;
  onCancel: () => void;
}

export const MicPermissionDialog = ({ isOpen, onAccept, onCancel }: MicPermissionDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onCancel()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Mic className="h-6 w-6 text-primary" />
          </div>
          <DialogTitle className="text-center">Microphone Access Required</DialogTitle>
          <DialogDescription className="text-center pt-2">
            Aila needs access to your microphone to have a voice conversation with you. 
            Your audio is processed securely and used only for this conversation.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-2 mt-4">
          <Button onClick={onAccept} className="w-full">
            Allow Microphone Access
          </Button>
          <Button onClick={onCancel} variant="outline" className="w-full">
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
