import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import ailaAvatar from "@/assets/aila-avatar.jpg";

interface WelcomeBubbleProps {
  onOpen: () => void;
  onDismiss: () => void;
}

export const WelcomeBubble = ({ onOpen, onDismiss }: WelcomeBubbleProps) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if bubble has been shown before
    const hasBeenShown = localStorage.getItem('ailaBubbleShown');
    
    if (hasBeenShown) {
      return; // Don't show if already shown before
    }

    // Show after 3 seconds
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const handleDismiss = (e: React.MouseEvent) => {
    e.stopPropagation();
    localStorage.setItem('ailaBubbleShown', 'true');
    setIsVisible(false);
    onDismiss();
  };

  const handleClick = () => {
    localStorage.setItem('ailaBubbleShown', 'true');
    setIsVisible(false);
    onOpen();
  };

  if (!isVisible) return null;

  return (
    <div
      onClick={handleClick}
      className="fixed bottom-24 right-4 max-w-[320px] bg-card border border-border rounded-2xl shadow-lg p-3 cursor-pointer hover:shadow-xl transition-all duration-300 animate-in slide-in-from-bottom-4 z-40"
    >
      <button
        onClick={handleDismiss}
        className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 transition-colors"
      >
        <X className="h-3 w-3" />
      </button>
      
      <div className="flex items-start gap-3">
        <Avatar className="h-10 w-10 flex-shrink-0">
          <img 
            src={ailaAvatar} 
            alt="Aila" 
            className="h-full w-full object-cover rounded-full"
          />
        </Avatar>
        
        <div className="flex-1 min-w-0">
          <p className="text-sm text-foreground leading-relaxed">
            👋 Hi! I'm Aila, your virtual assistant. Need help booking a meeting or learning more about our services?
          </p>
        </div>
      </div>
    </div>
  );
};
