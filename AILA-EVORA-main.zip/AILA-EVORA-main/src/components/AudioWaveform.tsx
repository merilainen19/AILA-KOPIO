interface AudioWaveformProps {
  isActive: boolean;
}

export const AudioWaveform = ({ isActive }: AudioWaveformProps) => {
  const bars = [
    { height: 20, delay: 0 },
    { height: 35, delay: 0.1 },
    { height: 50, delay: 0.2 },
    { height: 40, delay: 0.15 },
    { height: 60, delay: 0.25 },
    { height: 45, delay: 0.18 },
    { height: 30, delay: 0.12 },
  ];

  return (
    <div className="flex items-center justify-center gap-1.5 h-20">
      {bars.map((bar, i) => (
        <div
          key={i}
          className={`w-1.5 bg-primary rounded-full transition-all duration-200 ${
            isActive ? 'animate-pulse' : ''
          }`}
          style={{
            height: isActive ? `${bar.height}px` : '12px',
            animationDelay: `${bar.delay}s`,
            animationDuration: `${0.6 + (i % 3) * 0.15}s`,
          }}
        />
      ))}
    </div>
  );
};
