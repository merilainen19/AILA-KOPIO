import { KeyboardEvent, useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Send, AudioLines, Square } from "lucide-react";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
  onConversationModeToggle: () => void;
  isConversationMode: boolean;
  onStopBot: () => void;
  isBotActive: boolean;
  shouldFocusInput?: boolean;
  message: string;
  onMessageChange: (message: string) => void;
}

export const ChatInput = ({ 
  onSendMessage, 
  disabled = false,
  onConversationModeToggle,
  isConversationMode,
  onStopBot,
  isBotActive,
  shouldFocusInput = false,
  message,
  onMessageChange,
}: ChatInputProps) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-focus input when shouldFocusInput changes
  useEffect(() => {
    if (shouldFocusInput && textareaRef.current && !isBotActive) {
      textareaRef.current.focus();
    }
  }, [shouldFocusInput, isBotActive]);

  // Auto-resize textarea based on content
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const newHeight = Math.min(textareaRef.current.scrollHeight, 96); // Max 96px (~4 lines)
      textareaRef.current.style.height = `${newHeight}px`;
    }
  }, [message]);

  const handleSend = () => {
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      onMessageChange("");
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t border-border bg-chat-footerBg p-4">
      <div className="flex items-center gap-2 max-w-4xl mx-auto">
        <Textarea
          ref={textareaRef}
          value={message}
          onChange={(e) => onMessageChange(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Type your message..."
          disabled={disabled || isBotActive}
          inputMode="text"
          style={{ fontSize: '16px' }}
          className="flex-1 bg-chat-inputBg border-input focus-visible:ring-primary resize-none min-h-[40px] max-h-[96px] overflow-y-auto scrollbar-thin [touch-action:manipulation] [-webkit-text-size-adjust:100%]"
          rows={1}
        />

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={isBotActive ? onStopBot : handleSend}
              disabled={(disabled && !isBotActive) || (!message.trim() && !isBotActive)}
              className="shrink-0 hover:bg-secondary/80 hover:scale-110 transition-all duration-200"
            >
              {isBotActive ? (
                <Square className="h-5 w-5 text-muted-foreground fill-muted-foreground transition-all duration-200" />
              ) : (
                <Send className="h-5 w-5 text-primary transition-transform duration-200" />
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent 
            side="top" 
            className="bg-foreground/90 text-background rounded-lg px-3 py-1.5"
          >
            <p className="text-sm">
              {isBotActive ? "Stop response" : "Send message"}
            </p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={onConversationModeToggle}
              className="shrink-0 hover:bg-secondary/80 hover:scale-110 transition-all duration-200"
            >
              <AudioLines className={`h-5 w-5 transition-colors duration-200 ${isConversationMode ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`} />
            </Button>
          </TooltipTrigger>
          <TooltipContent 
            side="top" 
            className="bg-foreground/90 text-background rounded-lg px-3 py-1.5"
          >
            <p className="text-sm">
              {isConversationMode ? "Exit Voice Mode" : "Start Voice Conversation"}
            </p>
          </TooltipContent>
        </Tooltip>
      </div>
    </div>
  );
};
