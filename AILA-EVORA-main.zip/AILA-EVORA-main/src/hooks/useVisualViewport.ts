import { useState, useEffect } from 'react';

interface VisualViewportState {
  height: number;
  keyboardHeight: number;
  isKeyboardOpen: boolean;
}

/**
 * Hook to track Visual Viewport changes and detect mobile keyboard
 * This helps position elements correctly when the virtual keyboard opens
 */
export const useVisualViewport = () => {
  const [viewportState, setViewportState] = useState<VisualViewportState>({
    height: window.visualViewport?.height || window.innerHeight,
    keyboardHeight: 0,
    isKeyboardOpen: false,
  });

  useEffect(() => {
    if (!window.visualViewport) {
      return;
    }

    const initialHeight = window.innerHeight;

    const handleViewportChange = () => {
      const currentHeight = window.visualViewport!.height;
      const keyboardHeight = initialHeight - currentHeight;
      const isKeyboardOpen = keyboardHeight > 100; // Threshold to detect keyboard

      setViewportState({
        height: currentHeight,
        keyboardHeight: Math.max(0, keyboardHeight),
        isKeyboardOpen,
      });
    };

    window.visualViewport.addEventListener('resize', handleViewportChange);
    window.visualViewport.addEventListener('scroll', handleViewportChange);

    return () => {
      window.visualViewport?.removeEventListener('resize', handleViewportChange);
      window.visualViewport?.removeEventListener('scroll', handleViewportChange);
    };
  }, []);

  return viewportState;
};
